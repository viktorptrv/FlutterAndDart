import 'package:flutter/material.dart';
import 'input_page.dart';

void main() => runApp(BMICalculator());

class BMICalculator extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        appBarTheme: AppBarThemeData(
          backgroundColor: Colors.greenAccent,
          foregroundColor: Colors.black87,
        ),
        scaffoldBackgroundColor: Colors.teal,
      ),
      home: InputPage(),
    );
  }
}

