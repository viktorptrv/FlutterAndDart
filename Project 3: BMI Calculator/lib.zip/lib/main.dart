import 'package:flutter/material.dart';
import 'input_page.dart';

void main() => runApp(BMICalculator());

class BMICalculator extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        appBarTheme: AppBarThemeData(
          backgroundColor: Colors.greenAccent,
          foregroundColor: Colors.black87,
        ),
        sliderTheme: SliderThemeData(
          thumbColor: Colors.pinkAccent,
          thumbShape: RoundSliderThumbShape(enabledThumbRadius: 15),
          overlayShape: RoundSliderOverlayShape(overlayRadius: 21),
          overlayColor: Colors.white60,
        ),
        scaffoldBackgroundColor: Colors.teal,
      ),
      home: InputPage(),
    );
  }
}

