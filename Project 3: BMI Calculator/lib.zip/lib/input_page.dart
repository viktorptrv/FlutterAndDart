import 'package:flutter/material.dart';

class InputPage extends StatefulWidget {
  @override
  _InputPageState createState() => _InputPageState();
}

class _InputPageState extends State<InputPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Expanded(
            flex: 1,
            child: Row(
              children: [
                ReusableContainer(colour: Colors.tealAccent, height: 200, width: 170),
                ReusableContainer(colour: Colors.tealAccent, height: 200, width: 170),
              ],
            ),
          ),
          Expanded(
            flex: 1,
            child: Row(
              children: [
                Container(
                  height: 200,
                  width: 360,
                  margin: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.tealAccent,
                    borderRadius: BorderRadius.circular(15.0),
                  ),
                )
              ],
            ),
          ),
          Expanded(
            flex: 1,
            child: Row(
              children: [
                ReusableContainer(colour: Colors.tealAccent, height: 200, width: 170),
                ReusableContainer(colour: Colors.tealAccent, height: 200, width: 170),
              ],
            ),
          )
        ],
      ),
    );
  }
}

class ReusableContainer extends StatelessWidget {
  final Color colour;
  final double height, width;
  ReusableContainer({super.key,
    required this.colour,
    required this.height,
    required this.width});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      width: width,
      margin: EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: colour,
        borderRadius: BorderRadius.circular(15),
      ),
    );
  }
}
