import 'dart:math';

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

const activeCardColour = Colors.greenAccent;
const inactiveCardColour = Colors.tealAccent;
const TextStyle txtStyle =  TextStyle(fontWeight: FontWeight.bold, fontSize: 20);
enum GenderFinal{male, female, non}
var gender;

class InputPage extends StatefulWidget {
  @override
  _InputPageState createState() => _InputPageState();
}

class _InputPageState extends State<InputPage> {

  Color maleCardColour = inactiveCardColour;
  Color femaleCardColour = inactiveCardColour;
  Color inactiveContainer = inactiveCardColour;

  int userHeight = 175;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Expanded(
            flex: 1,
            child: Row(
              children: [
                Expanded(child: ReusableContainer(colour:maleCardColour, height: 200, width: 170,
                  cardChild: GestureDetector(
                      onTap: (){
                        setState(() {
                          if (maleCardColour == inactiveCardColour){
                            maleCardColour = activeCardColour;
                            femaleCardColour = inactiveCardColour;
                            gender = GenderFinal.male;
                          }
                          else
                            maleCardColour = inactiveCardColour;
                        });
                      },
                      child: ReusableColumnChild(iconPic: Icons.male, message: 'Male'))
                ),
                ),
                Expanded(child: ReusableContainer(colour: femaleCardColour, height: 200, width: 170,
                  cardChild:GestureDetector(
                      onTap: (){
                        setState(() {
                          if (femaleCardColour == inactiveCardColour){
                            femaleCardColour = activeCardColour;
                            maleCardColour = inactiveCardColour;
                            gender = GenderFinal.female;
                          }
                          else{
                            femaleCardColour = inactiveCardColour;
                          }

                        });
                      },
                      child: ReusableColumnChild(iconPic: Icons.female, message: 'Female')))),
              ],
            ),
          ),
          Expanded(
            flex: 1,
            child: Row(
              children: [
                Expanded(
                  child: ReusableContainer(
                      colour: inactiveContainer,
                      height: 200, width: 360,
                      cardChild: Column(
                        children: [
                          Text('Whats your height?', style: txtStyle),
                          Text(userHeight.toString(), style: txtStyle),
                          Slider(value:userHeight.toDouble(), min: 120.0, max: 220.0,
                            onChanged: (double newValue){
                              setState(() {
                                userHeight = newValue.round(); // updating our value
                              });
                            },
                            activeColor: Colors.blueAccent,
                            inactiveColor: Colors.blue,
                          ),
                        ],
                      ),
                  )
                )
              ],
            ),
          ),
          Expanded(
            flex: 1,
            child: Row(
              children: [
                Expanded(child: ReusableContainer(colour: maleCardColour, height: 200, width: 170,
                  cardChild: ReusableColumnChild(iconPic: Icons.male, message: 'Male'),),),
                Expanded(child: ReusableContainer(colour: femaleCardColour, height: 200, width: 170,
                  cardChild: ReusableColumnChild(iconPic: Icons.male, message: 'Male'),
                ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class ReusableColumnChild extends StatelessWidget{
  final IconData iconPic;
  final String message;

  ReusableColumnChild ({
    super.key,
    required this.iconPic,
    required this.message,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        Icon(iconPic, size: 80,),
        SizedBox(height: 15.0),
        Text(message, style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold
        ),)
      ],
    );
  }
}

class ReusableContainer extends StatelessWidget {
  final Color colour;
  final double height, width;

  final Widget cardChild;

  ReusableContainer({super.key,
    required this.colour,
    required this.height,
    required this.width,
    required this.cardChild});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      width: width,
      margin: EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: colour,
        borderRadius: BorderRadius.circular(15),
      ),
      child: cardChild,
    );
  }
}
