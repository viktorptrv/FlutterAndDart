import 'dart:math';

import 'package:bmi_calculator/main.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

const activeCardColour = Colors.greenAccent;
const inactiveCardColour = Colors.tealAccent;
const TextStyle txtStyle =  TextStyle(fontWeight: FontWeight.bold, fontSize: 20);
enum GenderFinal{male, female, non}
var gender;

class InputPage extends StatefulWidget {
  @override
  _InputPageState createState() => _InputPageState();
}

class _InputPageState extends State<InputPage> {

  Color maleCardColour = inactiveCardColour;
  Color femaleCardColour = inactiveCardColour;
  Color inactiveContainer = inactiveCardColour;

  int userHeight = 175;
  int weight = 60;
  int userAge = 18;

  void minus(){
    weight--;
    print('$weight');
  }

  void plus(){
    weight++;
  }

  void agePlus(){
    userAge++;
  }

  void ageMinus(){
    userAge--;
  }

  int getGender(){
    if (gender == GenderFinal.male){
      return 0;
    }
    else if (gender == GenderFinal.female){
      return 1;
    }
    return -1;
  }

  double resultBMI(){
    return weight/(userHeight*userHeight);;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Expanded(
            flex: 1,
            child: Row(
              children: [
                Expanded(child: ReusableContainer(colour:maleCardColour, height: 200, width: 170,
                  cardChild: GestureDetector(
                      onTap: (){
                        setState(() {
                          if (maleCardColour == inactiveCardColour){
                            maleCardColour = activeCardColour;
                            femaleCardColour = inactiveCardColour;
                            gender = GenderFinal.male;
                          }
                          else
                            maleCardColour = inactiveCardColour;
                        });
                      },
                      child: ReusableColumnChild(iconPic: Icons.male, message: 'Male'))
                ),
                ),
                Expanded(child: ReusableContainer(colour: femaleCardColour, height: 200, width: 170,
                  cardChild:GestureDetector(
                      onTap: (){
                        setState(() {
                          if (femaleCardColour == inactiveCardColour){
                            femaleCardColour = activeCardColour;
                            maleCardColour = inactiveCardColour;
                            gender = GenderFinal.female;
                          }
                          else{
                            femaleCardColour = inactiveCardColour;
                          }

                        });
                      },
                      child: ReusableColumnChild(iconPic: Icons.female, message: 'Female')))),
              ],
            ),
          ),
          Expanded(
            flex: 1,
            child: Row(
              children: [
                Expanded(
                  child: ReusableContainer(
                      colour: inactiveContainer,
                      height: 200, width: 360,
                      cardChild: Column(
                        children: [
                          Text('Whats your height?', style: txtStyle),
                          Text(userHeight.toString(), style: txtStyle),
                          Slider(value:userHeight.toDouble(), min: 120.0, max: 220.0,
                            onChanged: (double newValue){
                              setState(() {
                                userHeight = newValue.round(); // updating our value
                              });
                            },
                            inactiveColor: Colors.blue,
                          ),
                        ],
                      ),
                  )
                )
              ],
            ),
          ),
          Expanded(
            flex: 1,
            child: Row(
              children: [
                Expanded(child: ReusableContainer(colour: Colors.tealAccent, height: 150, width: 170,
                  cardChild: Column(
                    children: [
                      Text('WEIGHT', style: txtStyle,),
                      SizedBox(height: 10,),
                      Text(weight.toString(), style: txtStyle,),
                      SizedBox(height: 10,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          RoundIconButton(function: (){
                            setState(() {
                              plus();
                            });
                          }, iconData: Icon(Icons.add),),
                          SizedBox(width: 10 ,),
                          RoundIconButton(function: (){
                            setState(() {
                              minus();
                            });
                          }, iconData: Icon(Icons.remove),),
                        ],
                      ),
                    ],
                  ),),),

                Expanded(child: ReusableContainer(colour: Colors.tealAccent, height: 150, width: 170,
                  cardChild:Column(
                    children: [
                      Text('AGE', style: txtStyle),
                      SizedBox(height: 10,),
                      Text(userAge.toString(),style: txtStyle,),
                      SizedBox(height: 10,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          RoundIconButton(
                              iconData: Icon(Icons.add),
                              function: (){
                                setState(() {
                                  agePlus();
                                });
                              }),
                          SizedBox(width: 10,),
                          RoundIconButton(
                              iconData: Icon(Icons.remove),
                              function: (){
                                setState(() {
                                  ageMinus();
                                });
                              })
                        ],
                      )
                    ],
                  ),
                ),
                ),
              ],
            ),
          ),
          Expanded(
              child: ReusableContainer(
                  colour: Colors.tealAccent,
                  height: 10, width: 200,
                  cardChild: TextButton(
                      onPressed: (){
                        setState(() {
                          Navigator.push(
                            context, MaterialPageRoute (
                              builder: (context) => CalculateBMI(results:(resultBMI()*10000).roundToDouble())));
                        });
                      },
                      child: Text(
                        'Calculate',
                        style: txtStyle,
                      ))),
          )
        ],
      ),
    );
  }
}

class ReusableColumnChild extends StatelessWidget{
  final IconData iconPic;
  final String message;

  ReusableColumnChild ({
    super.key,
    required this.iconPic,
    required this.message,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        Icon(iconPic, size: 80,),
        SizedBox(height: 15.0),
        Text(message, style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold
        ),)
      ],
    );
  }
}

class ReusableContainer extends StatelessWidget {
  final Color colour;
  final double height, width;

  final Widget cardChild;

  ReusableContainer({super.key,
    required this.colour,
    required this.height,
    required this.width,
    required this.cardChild});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      width: width,
      margin: EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: colour,
        borderRadius: BorderRadius.circular(15),
      ),
      child: cardChild,
    );
  }
}

class RoundIconButton extends StatelessWidget{

  final Icon iconData;
  final Function function;

  RoundIconButton({
    required this.iconData,
    required this.function,
});

  @override
  Widget build(BuildContext context) {
    return RawMaterialButton(
      onPressed: (){
        function();
      },
      shape: CircleBorder(),
      fillColor: Colors.white60,
      hoverColor: Colors.greenAccent,
      constraints: BoxConstraints.tightFor(width: 56.0, height: 56.0),
      elevation: 6.0,
      child: iconData,
    );
  }
}

class CalculateBMI extends StatelessWidget{
  final double results;

  const CalculateBMI({
    super.key,
    required this.results,
  });

  String topText(){
    String top = 'Normal';
    if (results < 18.5)
      top = 'Underweight';
    else if (results >= 18.8 && results <= 24.9)
      top = 'Normal';
    else if (results > 24.9 && results <= 29.9)
      top = 'Overweight';
    else
      top = 'Obese';
    return top;
  }

  String finalText(){
    String finaltxt;
    if (results < 18.5)
      finaltxt = 'You are Underweight';
    else if (results >= 18.8 && results <= 24.9)
      finaltxt = 'You are Normal';
    else if (results > 24.9 && results <= 29.9)
      finaltxt = 'You are Overweight';
    else
      finaltxt = 'You are Obese';
    return finaltxt;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('BMI Calculations'),),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Center(
            child: Text(
              'Your Results',
              style: txtStyle,),
          ),
          SizedBox(height: 10,),
          Expanded(
            child: Container(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    '${topText()}',
                    style: txtStyle,
                  ),
                  SizedBox(height: 15,),
                  Text(
                    results.toString(),
                    style: TextStyle(
                      fontSize: 25,
                      fontWeight: FontWeight.bold
                    ),
                  ),
                  SizedBox(height: 15,),
                  Text(
                    '${finalText()}',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold
                    ),
                  )
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}