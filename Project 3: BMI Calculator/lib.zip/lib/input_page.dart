import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class InputPage extends StatefulWidget {
  @override
  _InputPageState createState() => _InputPageState();
}

class _InputPageState extends State<InputPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Expanded(
            flex: 1,
            child: Row(
              children: [
                Expanded(child: ReusableContainer(colour: Colors.tealAccent, height: 200, width: 170,
                  cardChild: ReusableColumnChild(iconPic: Icons.male, message: 'Male')
                ),
                ),
                Expanded(child: ReusableContainer(colour: Colors.tealAccent, height: 200, width: 170,
                  cardChild:ReusableColumnChild(iconPic: Icons.female, message: 'Female'))),
              ],
            ),
          ),
          Expanded(
            flex: 1,
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    height: 200,
                    width: 360,
                    margin: EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Colors.tealAccent,
                      borderRadius: BorderRadius.circular(15.0),
                    ),
                  ),
                )
              ],
            ),
          ),
          Expanded(
            flex: 1,
            child: Row(
              children: [
                Expanded(child: ReusableContainer(colour: Colors.tealAccent, height: 200, width: 170,
                  cardChild: ReusableColumnChild(iconPic: Icons.male, message: 'Male'),),),
                Expanded(child: ReusableContainer(colour: Colors.tealAccent, height: 200, width: 170,
                  cardChild: ReusableColumnChild(iconPic: Icons.male, message: 'Male'),
                ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class ReusableColumnChild extends StatelessWidget{
  final IconData iconPic;
  final String message;

  ReusableColumnChild ({
    super.key,
    required this.iconPic,
    required this.message,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        Icon(iconPic, size: 80,),
        SizedBox(height: 15.0),
        Text(message, style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold
        ),)
      ],
    );
  }
}

class ReusableContainer extends StatelessWidget {
  final Color colour;
  final double height, width;

  final Widget cardChild;

  ReusableContainer({super.key,
    required this.colour,
    required this.height,
    required this.width,
    required this.cardChild});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      width: width,
      margin: EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: colour,
        borderRadius: BorderRadius.circular(15),
      ),
      child: cardChild,
    );
  }
}
